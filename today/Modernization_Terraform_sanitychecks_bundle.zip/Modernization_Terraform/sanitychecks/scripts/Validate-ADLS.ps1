param(
  [Parameter(Mandatory)][string]$TenantId,[Parameter(Mandatory)][string]$ClientId,[Parameter(Mandatory)][string]$ClientSecret,
  [Parameter(Mandatory)][string]$adh_group,[ValidateSet('nonprd','prd')][string]$adh_subscription_type='nonprd',
  [Parameter(Mandatory)][string]$InputCsvPath,[Parameter(Mandatory)][string]$OutputDir,[string]$BranchName=''
)
Import-Module Az.Accounts, Az.Resources, Az.Storage -ErrorAction Stop
Import-Module (Join-Path $PSScriptRoot 'Common.psm1') -Force -ErrorAction Stop
Ensure-Dir $OutputDir | Out-Null
if (-not (Test-Path -LiteralPath $InputCsvPath)) { throw "ADLS CSV not found: $InputCsvPath" }
$rows = Import-Csv $InputCsvPath
if (-not (Connect-ScAz -TenantId $TenantId -ClientId $ClientId -ClientSecret $ClientSecret)) { throw "Azure connection failed." }
$subs = Resolve-ScSubscriptions -AdhGroup $adh_group -Environment $adh_subscription_type
$out=@()
foreach($sub in $subs){
  Set-ScContext -Subscription $sub
  foreach($r in $rows){
    $rgName  = ($r.ResourceGroupName -replace '<Custodian>', $adh_group)
    $saName  = ($r.StorageAccountName -replace '<Cust>', $adh_group.ToLower())
    $cont    = $r.ContainerName
    $sa = Get-AzStorageAccount -ResourceGroupName $rgName -Name $saName -ErrorAction SilentlyContinue
    if (-not $sa) { $out += [pscustomobject]@{ SubscriptionName=$sub.Name; ResourceGroup=$rgName; Storage=$saName; Container=$cont; Check='StorageAccount'; Status='MISSING'; Notes='Storage Account not found' }; continue }
    $ctx = $sa.Context
    $container = Get-AzStorageContainer -Name $cont -Context $ctx -ErrorAction SilentlyContinue
    if (-not $container) { $out += [pscustomobject]@{ SubscriptionName=$sub.Name; ResourceGroup=$rgName; Storage=$saName; Container=$cont; Check='Container'; Status='MISSING'; Notes='Container not found' }; continue }
    $out += [pscustomobject]@{ SubscriptionName=$sub.Name; ResourceGroup=$rgName; Storage=$saName; Container=$cont; Check='ACL'; Status='SKIPPED'; Notes='Add detailed ACL logic if needed' }
  }
}
$csvOut = New-StampedPath -BaseDir $OutputDir -Prefix "adls_validation_${adh_group}_${adh_subscription_type}"
Write-CsvSafe -Rows $out -Path $csvOut
Convert-CsvToHtml -CsvPath $csvOut -HtmlPath ($csvOut -replace '\.csv$','.html') -Title "ADLS Validation ($adh_group / $adh_subscription_type) $BranchName"
