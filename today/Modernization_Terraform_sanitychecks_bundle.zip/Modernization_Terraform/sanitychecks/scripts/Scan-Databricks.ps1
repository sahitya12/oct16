param(
  [Parameter(Mandatory)][string]$TenantId,[Parameter(Mandatory)][string]$ClientId,[Parameter(Mandatory)][string]$ClientSecret,
  [Parameter(Mandatory)][string]$adh_group,[ValidateSet('nonprd','prd')][string]$adh_subscription_type='nonprd',
  [Parameter(Mandatory)][string]$OutputDir,[string]$BranchName='',[string]$WorkspaceHostMapCsvPath=''
)
Import-Module Az.Accounts, Az.Resources -ErrorAction Stop
Import-Module (Join-Path $PSScriptRoot 'Common.psm1') -Force -ErrorAction Stop
Ensure-Dir $OutputDir | Out-Null
if (-not (Connect-ScAz -TenantId $TenantId -ClientId $ClientId -ClientSecret $ClientSecret)) { throw "Azure connection failed." }
$workspaceHostMap=@{}
if ($WorkspaceHostMapCsvPath -and (Test-Path -LiteralPath $WorkspaceHostMapCsvPath)) {
  (Import-Csv $WorkspaceHostMapCsvPath) | % { if($_.WorkspaceName -and $_.Host){ $workspaceHostMap[$_.WorkspaceName]=$_.Host.TrimEnd('/') } }
}
$wsRows=@(); $jobRows=@(); $permRows=@()
$subs = Resolve-ScSubscriptions -AdhGroup $adh_group -Environment $adh_subscription_type
foreach($sub in $subs){
  Set-ScContext -Subscription $sub
  $workspaces = Get-AzResource -ResourceType "Microsoft.Databricks/workspaces" -ErrorAction SilentlyContinue
  if (-not $workspaces) { $wsRows += [pscustomobject]@{ SubscriptionName=$sub.Name; SubscriptionId=$sub.Id; WorkspaceName=''; ResourceGroup=''; Region=''; State='NoWorkspaces'; Notes='' }; continue }
  foreach($ws in $workspaces){
    $wsName=$ws.Name; $rg=$ws.ResourceGroupName; $loc=$ws.Location
    $state=($ws.Properties | Select-Object -ExpandProperty workspaceState -ErrorAction SilentlyContinue)
    $wsRows += [pscustomobject]@{ SubscriptionName=$sub.Name; SubscriptionId=$sub.Id; WorkspaceName=$wsName; ResourceGroup=$rg; Region=$loc; State=($state ?? 'Unknown'); Notes='' }
    $token=$env:DATABRICKS_TOKEN
    $host = if($workspaceHostMap.ContainsKey($wsName)){ $workspaceHostMap[$wsName] } else { $null }
    if (-not $host -or -not $token) {
      $permRows += [pscustomobject]@{ SubscriptionName=$sub.Name; WorkspaceName=$wsName; Area='Permissions'; Item='-'; Value='-'; Status='SKIPPED'; Notes='Missing token/host' }
      $jobRows  += [pscustomobject]@{ SubscriptionName=$sub.Name; WorkspaceName=$wsName; JobId='-'; Name='-'; Schedule='-'; Status='SKIPPED'; Notes='Missing token/host' }
      continue
    }
    try {
      $headers=@{ Authorization = "Bearer $token" }
      $jobsResp = Invoke-RestMethod -Method GET -Uri "$host/api/2.1/jobs/list" -Headers $headers -ErrorAction SilentlyContinue
      foreach($j in ($jobsResp.jobs ?? @())){
        $jobRows += [pscustomobject]@{ SubscriptionName=$sub.Name; WorkspaceName=$wsName; JobId=$j.job_id; Name=$j.settings.name; Schedule=($j.settings.schedule.quartz_cron_expression ?? ''); Status='OK'; Notes='' }
      }
      $permResp = Invoke-RestMethod -Method GET -Uri "$host/api/2.0/permissions/workspace" -Headers $headers -ErrorAction SilentlyContinue
      foreach($p in ($permResp.access_control_list ?? @())){
        $principal=($p.user_name ?? $p.group_name ?? $p.service_principal_name ?? '(unknown)')
        $perms = ($p.all_permissions | % { $_.permission_level }) -join ';'
        $permRows += [pscustomobject]@{ SubscriptionName=$sub.Name; WorkspaceName=$wsName; Area='Workspace'; Item=$principal; Value=$perms; Status='OK'; Notes='' }
      }
    } catch { $permRows += [pscustomobject]@{ SubscriptionName=$sub.Name; WorkspaceName=$wsName; Area='REST'; Item='Error'; Value=''; Status='ERROR'; Notes=$_.Exception.Message } }
  }
}
$csvA = New-StampedPath -BaseDir $OutputDir -Prefix "databricks_workspaces_${adh_group}_${adh_subscription_type}"
Write-CsvSafe -Rows $wsRows -Path $csvA
Convert-CsvToHtml -CsvPath $csvA -HtmlPath ($csvA -replace '\.csv$','.html') -Title "Databricks Workspaces ($adh_group / $adh_subscription_type) $BranchName"
$csvB = New-StampedPath -BaseDir $OutputDir -Prefix "databricks_jobs_${adh_group}_${adh_subscription_type}"
Write-CsvSafe -Rows $jobRows -Path $csvB
$csvC = New-StampedPath -BaseDir $OutputDir -Prefix "databricks_permissions_${adh_group}_${adh_subscription_type}"
Write-CsvSafe -Rows $permRows -Path $csvC
