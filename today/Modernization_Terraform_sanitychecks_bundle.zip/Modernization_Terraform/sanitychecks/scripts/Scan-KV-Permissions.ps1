param(
  [Parameter(Mandatory)][string]$TenantId,[Parameter(Mandatory)][string]$ClientId,[Parameter(Mandatory)][string]$ClientSecret,
  [Parameter(Mandatory)][string]$adh_group,[ValidateSet('nonprd','prd')][string]$adh_subscription_type='nonprd',
  [Parameter(Mandatory)][string]$OutputDir,[string]$BranchName=''
)
Import-Module Az.Accounts, Az.KeyVault, Az.Resources -ErrorAction Stop
Import-Module (Join-Path $PSScriptRoot 'Common.psm1') -Force -ErrorAction Stop
Ensure-Dir $OutputDir | Out-Null
if (-not (Connect-ScAz -TenantId $TenantId -ClientId $ClientId -ClientSecret $ClientSecret)) { throw "Azure connection failed." }
$subs = Resolve-ScSubscriptions -AdhGroup $adh_group -Environment $adh_subscription_type
$rows=@()
foreach($sub in $subs){
  Set-ScContext -Subscription $sub
  $kvs = Get-AzResource -ResourceType "Microsoft.KeyVault/vaults" -ErrorAction SilentlyContinue
  foreach($kv in $kvs){
    $pol = Get-AzKeyVaultAccessPolicy -VaultName $kv.Name -ErrorAction SilentlyContinue
    foreach($p in ($pol ?? @())){
      $rows += [pscustomobject]@{ SubscriptionName=$sub.Name; VaultName=$kv.Name; TenantId=$p.TenantId; ObjectId=$p.ObjectId; Permissions=(($p.PermissionsToSecrets + $p.PermissionsToKeys + $p.PermissionsToCertificates) -join ';') }
    }
  }
}
$csvOut = New-StampedPath -BaseDir $OutputDir -Prefix ("kv_rbac_{0}_{1}" -f $adh_group,$adh_subscription_type)
Write-CsvSafe -Rows $rows -Path $csvOut
