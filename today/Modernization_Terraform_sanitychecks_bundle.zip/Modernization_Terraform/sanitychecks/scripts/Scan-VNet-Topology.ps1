param(
  [Parameter(Mandatory)][string]$TenantId,[Parameter(Mandatory)][string]$ClientId,[Parameter(Mandatory)][string]$ClientSecret,
  [Parameter(Mandatory)][string]$adh_group,[ValidateSet('nonprd','prd')][string]$adh_subscription_type='nonprd',
  [Parameter(Mandatory)][string]$OutputDir,[string]$BranchName=''
)
Import-Module Az.Accounts, Az.Network, Az.Resources -ErrorAction Stop
Import-Module (Join-Path $PSScriptRoot 'Common.psm1') -Force -ErrorAction Stop
Ensure-Dir $OutputDir | Out-Null
if (-not (Connect-ScAz -TenantId $TenantId -ClientId $ClientId -ClientSecret $ClientSecret)) { throw "Azure connection failed." }
$subs = Resolve-ScSubscriptions -AdhGroup $adh_group -Environment $adh_subscription_type
$rows=@(); $peerRows=@()
foreach($sub in $subs){
  Set-ScContext -Subscription $sub
  $vnets = Get-AzVirtualNetwork -ErrorAction SilentlyContinue
  foreach($v in $vnets){
    $rows += [pscustomobject]@{ SubscriptionName=$sub.Name; VNetName=$v.Name; ResourceGroup=$v.ResourceGroupName; AddressSpace=($v.AddressSpace.AddressPrefixes -join ','); DnsServers=($v.DhcpOptions.DnsServers -join ','); Subnets=(($v.Subnets|%{ $_.Name + '(' + ($_.AddressPrefix) + ')' }) -join ';') }
    foreach($p in $v.Peerings){
      $peerRows += [pscustomobject]@{ SubscriptionName=$sub.Name; VNetName=$v.Name; PeeringName=$p.Name; RemoteVNetId=$p.RemoteVirtualNetwork.Id; AllowForwarded=$p.AllowForwardedTraffic; AllowGateway=$p.AllowGatewayTransit; AllowVnetAccess=$p.AllowVirtualNetworkAccess }
    }
  }
}
$out1 = New-StampedPath -BaseDir $OutputDir -Prefix ("vnet_topology_{0}_{1}" -f $adh_group,$adh_subscription_type)
Write-CsvSafe -Rows $rows -Path $out1
Convert-CsvToHtml -CsvPath $out1 -HtmlPath ($out1 -replace '\.csv$','.html') -Title "VNet Topology ($adh_group / $adh_subscription_type) $BranchName"
$out2 = New-StampedPath -BaseDir $OutputDir -Prefix ("vnet_peerings_{0}_{1}" -f $adh_group,$adh_subscription_type)
Write-CsvSafe -Rows $peerRows -Path $out2
