param(
  [Parameter(Mandatory)][string]$TenantId,[Parameter(Mandatory)][string]$ClientId,[Parameter(Mandatory)][string]$ClientSecret,
  [Parameter(Mandatory)][string]$adh_group,[ValidateSet('nonprd','prd')][string]$adh_subscription_type='nonprd',
  [Parameter(Mandatory)][string]$InputCsvPath,[Parameter(Mandatory)][string]$OutputDir,[string]$BranchName=''
)
Import-Module Az.Accounts, Az.KeyVault, Az.Resources -ErrorAction Stop
Import-Module (Join-Path $PSScriptRoot 'Common.psm1') -Force -ErrorAction Stop
Ensure-Dir $OutputDir | Out-Null
if (-not (Test-Path -LiteralPath $InputCsvPath)) { throw "Secrets CSV not found: $InputCsvPath" }
$expected = Import-Csv $InputCsvPath
if (-not (Connect-ScAz -TenantId $TenantId -ClientId $ClientId -ClientSecret $ClientSecret)) { throw "Azure connection failed." }
$subs = Resolve-ScSubscriptions -AdhGroup $adh_group -Environment $adh_subscription_type
$rows=@()
foreach($sub in $subs){
  Set-ScContext -Subscription $sub
  $kvs = Get-AzResource -ResourceType "Microsoft.KeyVault/vaults" -ErrorAction SilentlyContinue
  foreach($kv in $kvs){
    foreach($e in $expected){
      $secretName = $e.SECRET_NAME
      $exists = $false
      try { $s = Get-AzKeyVaultSecret -VaultName $kv.Name -Name $secretName -ErrorAction Stop; $exists = $null -ne $s } catch { $exists = $false }
      $rows += [pscustomobject]@{ SubscriptionName=$sub.Name; VaultName=$kv.Name; ResourceGroup=$kv.ResourceGroupName; SecretName=$secretName; Exists= (if($exists){{'Yes'}}else{{'No'}}) }
    }
  }
}
$csvOut = New-StampedPath -BaseDir $OutputDir -Prefix ("kv_secrets_{0}_{1}" -f $adh_group,$adh_subscription_type)
Write-CsvSafe -Rows $rows -Path $csvOut
Convert-CsvToHtml -CsvPath $csvOut -HtmlPath ($csvOut -replace '\.csv$','.html') -Title "KV Secrets ($adh_group / $adh_subscription_type) $BranchName"
