param(
  [Parameter(Mandatory)][string]$TenantId,
  [Parameter(Mandatory)][string]$ClientId,
  [Parameter(Mandatory)][string]$ClientSecret,
  [string]$ProdCsvPath,
  [string]$NonProdCsvPath,
  [Parameter(Mandatory)][string]$adh_group,
  [ValidateSet('nonprd','prd')][string]$adh_subscription_type='nonprd',
  [Parameter(Mandatory)][string]$OutputDir,
  [string]$BranchName=''
)
Import-Module Az.Accounts, Az.Resources -ErrorAction Stop
Import-Module (Join-Path $PSScriptRoot 'Common.psm1') -Force -ErrorAction Stop
Ensure-Dir -Path $OutputDir | Out-Null
if (-not (Connect-ScAz -TenantId $TenantId -ClientId $ClientId -ClientSecret $ClientSecret)) { throw "Azure connection failed." }
$csvPath = if($adh_subscription_type -eq 'prd'){$ProdCsvPath}else{$NonProdCsvPath}
if(-not (Test-Path -LiteralPath $csvPath)){ throw "CSV not found: $csvPath" }
$inputRows = Import-Csv -Path $csvPath
$subs = Resolve-ScSubscriptions -AdhGroup $adh_group -Environment $adh_subscription_type
$result=@()
foreach($sub in $subs){
  Set-ScContext -Subscription $sub
  foreach($row in $inputRows){
    $rgName = $row.resource_group_name -replace '<Custodian>', $adh_group
    $role   = $row.role_definition_name
    $aadGrp = $row.ad_group_name -replace '<Custodian>', $adh_group
    $rg = Get-AzResourceGroup -Name $rgName -ErrorAction SilentlyContinue
    $rgStatus = if($rg){'EXISTS'}else{'NOT_FOUND'}
    $permStatus='N/A'; $details=''
    if($rg){
      $scope = "/subscriptions/{0}/resourceGroups/{1}" -f $sub.Id, $rgName
      $assign = Get-AzRoleAssignment -Scope $scope -ErrorAction SilentlyContinue | Where-Object { $_.RoleDefinitionName -eq $role -and $_.DisplayName -eq $aadGrp }
      $permStatus = if($assign){'EXISTS'}else{'MISSING'}
      if(-not $assign){ $details='Expected assignment not found at RG scope' }
    } else { $details='RG not found' }
    $result += [pscustomobject]@{ SubscriptionName=$sub.Name; SubscriptionId=$sub.Id; Environment=$adh_subscription_type; Custodian=$adh_group; InputResourceGroup=$row.resource_group_name; ScannedResourceGroup=$rgName; RoleDefinition=$role; InputAdGroup=$row.ad_group_name; ResolvedAdGroup=$aadGrp; RGStatus=$rgStatus; PermissionStatus=$permStatus; Details=$details }
  }
}
$csvOut = New-StampedPath -BaseDir $OutputDir -Prefix ("rg_permissions_{0}_{1}" -f $adh_group,$adh_subscription_type) -Ext 'csv'
Write-CsvSafe -Rows $result -Path $csvOut
Convert-CsvToHtml -CsvPath $csvOut -HtmlPath ([System.IO.Path]::ChangeExtension($csvOut,'html')) -Title "RG Permissions ($adh_group / $adh_subscription_type) $BranchName"
