
function Ensure-Dir { param([Parameter(Mandatory)][string]$Path) if(-not(Test-Path -LiteralPath $Path)){ New-Item -ItemType Directory -Path $Path -Force | Out-Null } return $Path }
function New-StampedPath { param([Parameter(Mandatory)][string]$BaseDir,[Parameter(Mandatory)][string]$Prefix,[string]$Ext='csv') $stamp=(Get-Date).ToString('yyyyMMdd_HHmmss'); Ensure-Dir -Path $BaseDir | Out-Null; Join-Path $BaseDir ("{0}_{1}.{2}" -f $Prefix,$stamp,$Ext) }
function Write-CsvSafe { param([Parameter(Mandatory)][array]$Rows,[Parameter(Mandatory)][string]$Path) if(-not $Rows){ $Rows=@() } $Rows | Export-Csv -Path $Path -NoTypeInformation -Force -Encoding UTF8 }
function Convert-CsvToHtml { param([Parameter(Mandatory)][string]$CsvPath,[Parameter(Mandatory)][string]$HtmlPath,[string]$Title='Report')
  $dt = Import-Csv $CsvPath; $html=@(); $html+='<html><head><meta charset="utf-8"><title>'+$Title+'</title><style>body{font-family:Segoe UI,Arial;font-size:13px} table{border-collapse:collapse} th,td{border:1px solid #ccc;padding:6px 8px}</style></head><body>';
  $html+='<h2>'+$Title+'</h2>'; if($dt -and $dt.Count -gt 0){ $html+='<table><tr>'; foreach($c in $dt[0].psobject.Properties.Name){ $html+='<th>'+$c+'</th>' }; $html+='</tr>'; foreach($r in $dt){ $html+='<tr>'; foreach($c in $dt[0].psobject.Properties.Name){ $v=$r.$c; if($v -ne $null){ $v = ($v -replace '<','&lt;') -replace '>','&gt;' } $html+='<td>'+$v+'</td>' }; $html+='</tr>' }; $html+='</table>' } else { $html+='<p><i>No rows.</i></p>' }
  $html+='</body></html>'; Set-Content -Path $HtmlPath -Value ($html -join "`n") -Encoding UTF8 }
function Connect-ScAz { param([Parameter(Mandatory)][string]$TenantId,[Parameter(Mandatory)][string]$ClientId,[Parameter(Mandatory)][string]$ClientSecret)
  try{ Import-Module Az.Accounts -ErrorAction Stop; $sec=ConvertTo-SecureString $ClientSecret -AsPlainText -Force; $cred=[pscredential]::new($ClientId,$sec); Connect-AzAccount -ServicePrincipal -Tenant $TenantId -Credential $cred -ErrorAction Stop | Out-Null; return $true } catch{ Write-Warning 'Az not available; skipping live queries.'; return $false } }
function Get-ScSubscriptions { param([Parameter(Mandatory)][string]$AdhGroup,[Parameter(Mandatory)][ValidateSet('nonprd','prd')][string]$Environment)
  if($AdhGroup -eq 'KTK'){ return @(@{ Name='dev_azure_20401_ADHPlatform'; Id='00000000-0000-0000-0000-000000000000' }) }
  $nameMatchEnv = if($Environment -eq 'prd'){'prd|prod|production'} else {'nonprd|dev|test|qa|nonprod'}
  try{ Import-Module Az.Accounts -ErrorAction Stop; $subs=Get-AzSubscription | Where-Object { $_.Name -match $nameMatchEnv -and $_.Name -match ('ADH.*{0}' -f [regex]::Escape($AdhGroup)) }; if($subs){ return $subs | ForEach-Object { @{Name=$_.Name; Id=$_.Id} } } } catch{}
  return @(@{ Name=('mock_{0}_{1}' -f $AdhGroup,$Environment); Id='00000000-0000-0000-0000-000000000001' })
}
