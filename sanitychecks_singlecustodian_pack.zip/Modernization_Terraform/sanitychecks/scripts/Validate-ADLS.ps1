param([Parameter(Mandatory)][string]$TenantId,[Parameter(Mandatory)][string]$ClientId,[Parameter(Mandatory)][string]$ClientSecret,[Parameter(Mandatory)][string]$CsvPath,[Parameter(Mandatory)][string]$adh_group,[ValidateSet('nonprd','prd')][string]$adh_subscription_type='nonprd',[Parameter(Mandatory)][string]$OutputDir,[string]$BranchName='')
Import-Module (Join-Path $PSScriptRoot 'Common.psm1') -Force
Ensure-Dir -Path $OutputDir | Out-Null
if(-not (Test-Path -LiteralPath $CsvPath)){ throw "CSV not found: $CsvPath" }
$input = Import-Csv $CsvPath
$connected = Connect-ScAz -TenantId $TenantId -ClientId $ClientId -ClientSecret $ClientSecret
$cust=$adh_group; $env=$adh_subscription_type
$rows=@()
foreach($r in $input){
  $rg  = $r.ResourceGroupName -replace '<Custodian>', $cust
  $sa  = $r.StorageAccountName -replace '<Cust>', $cust.ToLower()
  if($env -eq 'prd'){ $sa = $sa -replace 'nonprd','prd' }
  $rows += [pscustomobject]@{ ResourceGroup=$rg; StorageAccount=$sa; Container=$r.ContainerName; Identity=($r.Identity -replace '<Custodian>',$cust); AccessPath=$r.AccessPath; PermissionType=$r.PermissionType; Type=$r.Type; Scope=$r.Scope; Actual= if($connected){'UNKNOWN'}else{'SKIPPED_NO_AZ'}; Status= if($connected){'UNKNOWN'}else{'SKIPPED_NO_AZ'} }
}
$csvOut = New-StampedPath -BaseDir $OutputDir -Prefix ("adls_validation_{0}_{1}" -f $cust,$env) -Ext 'csv'
Write-CsvSafe -Rows $rows -Path $csvOut
Convert-CsvToHtml -CsvPath $csvOut -HtmlPath ([System.IO.Path]::ChangeExtension($csvOut,'html')) -Title "ADLS Validation ($cust / $env) $BranchName"
