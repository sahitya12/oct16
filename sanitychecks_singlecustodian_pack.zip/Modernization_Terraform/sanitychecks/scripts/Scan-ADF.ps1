param([Parameter(Mandatory)][string]$TenantId,[Parameter(Mandatory)][string]$ClientId,[Parameter(Mandatory)][string]$ClientSecret,[Parameter(Mandatory)][string]$adh_group,[ValidateSet('nonprd','prd')][string]$adh_subscription_type='nonprd',[Parameter(Mandatory)][string]$OutputDir,[string]$BranchName='')
Import-Module (Join-Path $PSScriptRoot 'Common.psm1') -Force
Ensure-Dir -Path $OutputDir | Out-Null
$connected = Connect-ScAz -TenantId $TenantId -ClientId $ClientId -ClientSecret $ClientSecret
$subs = Get-ScSubscriptions -AdhGroup $adh_group -Environment $adh_subscription_type
$rows=@()
foreach($sub in $subs){
  $rows += [pscustomobject]@{ SubscriptionName=$sub.Name; ResourceGroup="rg-$adh_group-data"; DataFactory="adf-$adh_group"; Exists= if($connected){'UNKNOWN'}else{'SKIPPED_NO_AZ'}; IntegrationRuntimes=''; LinkedServices=0; Notes= if($connected){'UNKNOWN'}else{'SKIPPED_NO_AZ'} }
}
$csvOut = New-StampedPath -BaseDir $OutputDir -Prefix ("adf_overview_{0}_{1}" -f $adh_group,$adh_subscription_type) -Ext 'csv'
Write-CsvSafe -Rows $rows -Path $csvOut
Convert-CsvToHtml -CsvPath $csvOut -HtmlPath ([System.IO.Path]::ChangeExtension($csvOut,'html')) -Title "ADF Overview ($adh_group / $adh_subscription_type) $BranchName"
