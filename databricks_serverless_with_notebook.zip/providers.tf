terraform {
  required_version = ">= 1.5.0"

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 4.0"
    }

    databricks = {
      source  = "databricks/databricks"
      version = "~> 1.61"
    }
  }
}

provider "azurerm" {
  features {}
}

provider "databricks" {
  host  = data.azurerm_key_vault_secret.databricks_host.value
  token = data.azurerm_key_vault_secret.databricks_pat.value
}
