# Databricks Serverless Job with Notebook - Terraform Sample

This sample shows how to:

- Read Databricks host from Azure Key Vault
- Read Databricks PAT token from Azure Key Vault
- Upload a notebook to the existing Databricks workspace
- Create a Databricks job that runs on serverless compute

## Files

- providers.tf
- variables.tf
- data.tf
- notebook.tf
- job.tf
- terraform.tfvars
- sample_notebook.py

## Required Key Vault Secrets

Create these two secrets in your Azure Key Vault:

- databricks-host
- databricks-pat

Example values:

databricks-host
https://adb-1234567890123456.7.azuredatabricks.net

databricks-pat
dapiXXXXXXXXXXXXXXXX

## Run

terraform init
terraform plan
terraform apply

## Notes

- The notebook will be uploaded to: /Shared/jobs/sample_notebook
- The job will reference that uploaded notebook
- Protect Terraform state because secrets may still appear in state
