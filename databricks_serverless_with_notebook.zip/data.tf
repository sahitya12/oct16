data "azurerm_key_vault" "kv" {
  name                = var.key_vault_name
  resource_group_name = var.resource_group_name
}

data "azurerm_key_vault_secret" "databricks_host" {
  name         = var.databricks_host_secret_name
  key_vault_id = data.azurerm_key_vault.kv.id
}

data "azurerm_key_vault_secret" "databricks_pat" {
  name         = var.databricks_pat_secret_name
  key_vault_id = data.azurerm_key_vault.kv.id
}
