resource "databricks_notebook" "sample_notebook" {
  path     = "/Shared/jobs/sample_notebook"
  language = "PYTHON"
  source   = "${path.module}/sample_notebook.py"
}
