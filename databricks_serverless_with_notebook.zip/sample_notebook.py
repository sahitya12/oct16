# Databricks notebook source
print("Hello from Databricks Serverless Job")

# COMMAND ----------
import pandas as pd

data = {
    "name": ["Alice", "Bob", "Charlie"],
    "score": [85, 92, 78]
}

df = pd.DataFrame(data)
display(df)

# COMMAND ----------
avg_score = df["score"].mean()
print(f"Average score: {avg_score}")

# COMMAND ----------
import requests
print("requests version loaded successfully")
