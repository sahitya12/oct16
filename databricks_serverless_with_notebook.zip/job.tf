resource "databricks_job" "serverless_job" {
  name = var.job_name

  task {
    task_key = "run-notebook-on-serverless"

    notebook_task {
      notebook_path = databricks_notebook.sample_notebook.path
    }

    environment_key = "default_env"
  }

  environment {
    environment_key = "default_env"
    spec {
      client       = "1"
      dependencies = ["pandas", "requests"]
    }
  }

  tags = {
    purpose = "serverless"
    managed = "terraform"
  }
}
