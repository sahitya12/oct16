variable "resource_group_name" {
  type = string
}

variable "key_vault_name" {
  type = string
}

variable "databricks_host_secret_name" {
  type    = string
  default = "databricks-host"
}

variable "databricks_pat_secret_name" {
  type    = string
  default = "databricks-pat"
}

variable "job_name" {
  type    = string
  default = "sample-serverless-job"
}
