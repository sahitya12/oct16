param(
    [Parameter(Mandatory)][string]$TenantId,
    [Parameter(Mandatory)][string]$ClientId,
    [Parameter(Mandatory)][string]$ClientSecret,
    [string]$adh_group = '',
    [ValidateSet('nonprd','prd')][string]$adh_subscription_type = 'nonprd',
    [Parameter(Mandatory)][string]$OutputDir
)
Import-Module (Join-Path $PSScriptRoot 'Common.psm1') -Force
Ensure-Dir -Path $OutputDir
Connect-ScAz -TenantId $TenantId -ClientId $ClientId -ClientSecret $ClientSecret

$subs = if ($adh_group) { Get-ScSubscriptions -AdhGroup $adh_group -Environment $adh_subscription_type } else { Get-ScAllAdhSubscriptions }
$rows = @()

foreach($sub in $subs){
    Set-AzContext -SubscriptionId $sub.Id | Out-Null
    $vaults = Get-AzKeyVault -ErrorAction SilentlyContinue
    foreach($v in $vaults){
        $rows += [pscustomobject]@{
            SubscriptionName    = $sub.Name
            SubscriptionId      = $sub.Id
            Vault               = $v.VaultName
            ResourceGroup       = $v.ResourceGroupName
            PublicNetworkAccess = $v.PublicNetworkAccess
            DefaultAction       = $v.NetworkAcls.DefaultAction
            IpRules             = ($v.NetworkAcls.IpAddressRanges -join ',')
            VnetRules           = (($v.NetworkAcls.VirtualNetworkResourceIds) -join ',')
        }
    }
}

$csv = New-StampedPath -BaseDir $OutputDir -Prefix "kv_networks" -Ext 'csv'
Write-CsvSafe -Rows $rows -Path $csv
