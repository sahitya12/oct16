param(
    [Parameter(Mandatory)][string]$TenantId,
    [Parameter(Mandatory)][string]$ClientId,
    [Parameter(Mandatory)][string]$ClientSecret,
    [string]$adh_group = '',
    [ValidateSet('nonprd','prd')][string]$adh_subscription_type = 'nonprd',
    [Parameter(Mandatory)][string]$OutputDir
)
Import-Module (Join-Path $PSScriptRoot 'Common.psm1') -Force
Ensure-Dir -Path $OutputDir
Connect-ScAz -TenantId $TenantId -ClientId $ClientId -ClientSecret $ClientSecret

$subs = if ($adh_group) { Get-ScSubscriptions -AdhGroup $adh_group -Environment $adh_subscription_type } else { Get-ScAllAdhSubscriptions }
$rbacRows = @()
$polRows  = @()

foreach($sub in $subs){
    Set-AzContext -SubscriptionId $sub.Id | Out-Null
    $vaults = Get-AzKeyVault -ErrorAction SilentlyContinue
    foreach($v in $vaults){
        $scope = $v.ResourceId
        $assign = Get-AzRoleAssignment -Scope $scope -ErrorAction SilentlyContinue
        foreach($a in $assign){
            $rbacRows += [pscustomobject]@{
                SubscriptionName = $sub.Name
                SubscriptionId   = $sub.Id
                Vault            = $v.VaultName
                ResourceGroup    = $v.ResourceGroupName
                Principal        = $a.DisplayName
                PrincipalId      = $a.ObjectId
                Role             = $a.RoleDefinitionName
                Scope            = $a.Scope
            }
        }

        $pol = Get-AzKeyVault -VaultName $v.VaultName -ResourceGroupName $v.ResourceGroupName
        foreach($p in $pol.AccessPolicies){
            $polRows += [pscustomobject]@{
                SubscriptionName = $sub.Name
                SubscriptionId   = $sub.Id
                Vault            = $v.VaultName
                ResourceGroup    = $v.ResourceGroupName
                ObjectId         = $p.ObjectId
                Secrets          = ($p.PermissionsToSecrets -join ',')
                Keys             = ($p.PermissionsToKeys -join ',')
                Certificates     = ($p.PermissionsToCertificates -join ',')
                Storage          = ($p.PermissionsToStorage -join ',')
            }
        }
    }
}

$rbacCsv = New-StampedPath -BaseDir $OutputDir -Prefix "kv_rbac" -Ext 'csv'
Write-CsvSafe -Rows $rbacRows -Path $rbacCsv
$polCsv  = New-StampedPath -BaseDir $OutputDir -Prefix "kv_accesspolicies" -Ext 'csv'
Write-CsvSafe -Rows $polRows -Path $polCsv
