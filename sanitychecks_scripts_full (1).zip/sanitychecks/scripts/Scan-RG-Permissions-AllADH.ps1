param(
    [Parameter(Mandatory)][string]$TenantId,
    [Parameter(Mandatory)][string]$ClientId,
    [Parameter(Mandatory)][string]$ClientSecret,
    [string]$ProdCsvPath,
    [string]$NonProdCsvPath,
    [ValidateSet('nonprd','prd')][string]$adh_subscription_type = 'nonprd',
    [Parameter(Mandatory)][string]$OutputDir,
    [string]$BranchName = ''
)
Import-Module (Join-Path $PSScriptRoot 'Common.psm1') -Force
Ensure-Dir -Path $OutputDir
Connect-ScAz -TenantId $TenantId -ClientId $ClientId -ClientSecret $ClientSecret

$csvPath = if ($adh_subscription_type -eq 'prd') { $ProdCsvPath } else { $NonProdCsvPath }
if (-not (Test-Path -LiteralPath $csvPath)) { throw "CSV not found: $csvPath" }
$expect = Import-Csv -Path $csvPath

$subs = Get-ScAllAdhSubscriptions
$result = @()

foreach($sub in $subs){
    Set-AzContext -SubscriptionId $sub.Id | Out-Null
    foreach($row in $expect){
        # Try to deduce custodian token from RG name placeholder if present
        $cust = ($row.resource_group_name -match '<Custodian>')
        $custodian = if ($cust) { 'ADH' } else { '' }  # placeholder; cannot infer reliably
        $rgName = $row.resource_group_name -replace '<Custodian>', $custodian
        $role = $row.role_definition_name
        $adGroup = $row.ad_group_name -replace '<Custodian>', $custodian

        $rg = Get-AzResourceGroup -Name $rgName -ErrorAction SilentlyContinue
        $rgStatus = if ($rg) { 'EXISTS' } else { 'NOT_FOUND' }
        $permStatus = 'N/A'

        if ($rg){
            $scope = "/subscriptions/{0}/resourceGroups/{1}" -f $sub.Id,$rgName
            $assign = Get-AzRoleAssignment -Scope $scope -ErrorAction SilentlyContinue | Where-Object {
                $_.RoleDefinitionName -eq $role -and $_.DisplayName -eq $adGroup
            }
            $permStatus = if ($assign) { 'EXISTS' } else { 'MISSING' }
        }

        $result += [pscustomobject]@{
            SubscriptionName   = $sub.Name
            SubscriptionId     = $sub.Id
            Environment        = $adh_subscription_type
            InputResourceGroup = $row.resource_group_name
            ScannedResourceGroup = $rgName
            RoleDefinition     = $role
            InputAdGroup       = $row.ad_group_name
            ResolvedAdGroup    = $adGroup
            RGStatus           = $rgStatus
            PermissionStatus   = $permStatus
            Details            = if ($rg) { '' } else { 'RG not found' }
        }
    }
}

$csvOut = New-StampedPath -BaseDir $OutputDir -Prefix "rg_permissions_ALLADH_${adh_subscription_type}" -Ext 'csv'
Write-CsvSafe -Rows $result -Path $csvOut
$htmlOut = [System.IO.Path]::ChangeExtension($csvOut, '.html')
Convert-CsvToHtml -CsvPath $csvOut -HtmlPath $htmlOut -Title "RG Permissions (ALL ADH / $adh_subscription_type) $BranchName"
