param(
    [Parameter(Mandatory)][string]$TenantId,
    [Parameter(Mandatory)][string]$ClientId,
    [Parameter(Mandatory)][string]$ClientSecret,
    [string]$adh_group = '',
    [ValidateSet('nonprd','prd')][string]$adh_subscription_type = 'nonprd',
    [Parameter(Mandatory)][string]$OutputDir
)
Import-Module (Join-Path $PSScriptRoot 'Common.psm1') -Force
Ensure-Dir -Path $OutputDir
Connect-ScAz -TenantId $TenantId -ClientId $ClientId -ClientSecret $ClientSecret

$subs = if ($adh_group) { Get-ScSubscriptions -AdhGroup $adh_group -Environment $adh_subscription_type } else { Get-ScAllAdhSubscriptions }
$sumRows = @()

foreach($sub in $subs){
    Set-AzContext -SubscriptionId $sub.Id | Out-Null
    try {
        $df = Get-AzDataFactory -ErrorAction SilentlyContinue
    } catch { $df = @() }
    if (-not $df) {
        $sumRows += [pscustomobject]@{ SubscriptionName=$sub.Name; ResourceGroup=''; DataFactory=''; Exists='No'; IntegrationRuntimes=''; LinkedServices=0; Notes='No ADF in sub' }
        continue
    }
    foreach($d in $df){
        $irs = Get-AzDataFactoryV2IntegrationRuntime -ResourceGroupName $d.ResourceGroupName -DataFactoryName $d.Name -ErrorAction SilentlyContinue
        $ls  = Get-AzDataFactoryV2LinkedService     -ResourceGroupName $d.ResourceGroupName -DataFactoryName $d.Name -ErrorAction SilentlyContinue
        $sumRows += [pscustomobject]@{
            SubscriptionName   = $sub.Name
            ResourceGroup      = $d.ResourceGroupName
            DataFactory        = $d.Name
            Exists             = 'Yes'
            IntegrationRuntimes= ($irs.Name -join ',')
            LinkedServices     = ($ls.Count)
            Notes              = ''
        }
    }
}

$csv = New-StampedPath -BaseDir $OutputDir -Prefix "adf_overview" -Ext 'csv'
Write-CsvSafe -Rows $sumRows -Path $csv
