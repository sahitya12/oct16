param(
    [Parameter(Mandatory)][string]$TenantId,
    [Parameter(Mandatory)][string]$ClientId,
    [Parameter(Mandatory)][string]$ClientSecret,
    [string]$ProdCsvPath,
    [string]$NonProdCsvPath,
    [string]$adh_group,
    [ValidateSet('nonprd','prd')][string]$adh_subscription_type = 'nonprd',
    [Parameter(Mandatory)][string]$OutputDir,
    [string]$BranchName = ''
)
Import-Module (Join-Path $PSScriptRoot 'Common.psm1') -Force
Ensure-Dir -Path $OutputDir
Connect-ScAz -TenantId $TenantId -ClientId $ClientId -ClientSecret $ClientSecret

# pick CSV by env
$csvPath = if ($adh_subscription_type -eq 'prd') { $ProdCsvPath } else { $NonProdCsvPath }
if (-not (Test-Path -LiteralPath $csvPath)) { throw "CSV not found: $csvPath" }

$subs = Get-ScSubscriptions -AdhGroup $adh_group -Environment $adh_subscription_type
$result = @()

$expect = Import-Csv -Path $csvPath
foreach($sub in $subs){
    Set-AzContext -SubscriptionId $sub.Id | Out-Null
    foreach($row in $expect){
        $rgName = $row.resource_group_name -replace '<Custodian>', $adh_group
        $role = $row.role_definition_name
        $adGroup = $row.ad_group_name -replace '<Custodian>', $adh_group

        $rg = Get-AzResourceGroup -Name $rgName -ErrorAction SilentlyContinue
        $rgStatus = if ($rg) { 'EXISTS' } else { 'NOT_FOUND' }
        $permStatus = 'N/A'

        if ($rg){
            # Try to find role assignment at RG scope with matching role + principal display name
            $scope = "/subscriptions/{0}/resourceGroups/{1}" -f $sub.Id,$rgName
            $assign = Get-AzRoleAssignment -Scope $scope -ErrorAction SilentlyContinue | Where-Object {
                $_.RoleDefinitionName -eq $role -and $_.DisplayName -eq $adGroup
            }
            $permStatus = if ($assign) { 'EXISTS' } else { 'MISSING' }
        }

        $result += [pscustomobject]@{
            SubscriptionName   = $sub.Name
            SubscriptionId     = $sub.Id
            Environment        = $adh_subscription_type
            InputResourceGroup = $row.resource_group_name
            ScannedResourceGroup = $rgName
            RoleDefinition     = $role
            InputAdGroup       = $row.ad_group_name
            ResolvedAdGroup    = $adGroup
            RGStatus           = $rgStatus
            PermissionStatus   = $permStatus
            Details            = if ($rg) { '' } else { 'RG not found' }
        }
    }
}

$csvOut = New-StampedPath -BaseDir $OutputDir -Prefix "rg_permissions_${adh_group}_${adh_subscription_type}" -Ext 'csv'
Write-CsvSafe -Rows $result -Path $csvOut
$htmlOut = [System.IO.Path]::ChangeExtension($csvOut, '.html')
Convert-CsvToHtml -CsvPath $csvOut -HtmlPath $htmlOut -Title "RG Permissions ($adh_group / $adh_subscription_type) $BranchName"
