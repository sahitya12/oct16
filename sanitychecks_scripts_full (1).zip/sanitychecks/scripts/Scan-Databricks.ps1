param(
    [Parameter(Mandatory)][string]$TenantId,
    [Parameter(Mandatory)][string]$ClientId,
    [Parameter(Mandatory)][string]$ClientSecret,
    [string]$adh_group = '',
    [ValidateSet('nonprd','prd')][string]$adh_subscription_type = 'nonprd',
    [Parameter(Mandatory)][string]$OutputDir
)
Import-Module (Join-Path $PSScriptRoot 'Common.psm1') -Force
Ensure-Dir -Path $OutputDir
Connect-ScAz -TenantId $TenantId -ClientId $ClientId -ClientSecret $ClientSecret

$subs = if ($adh_group) { Get-ScSubscriptions -AdhGroup $adh_group -Environment $adh_subscription_type } else { Get-ScAllAdhSubscriptions }
$rows = @()

foreach($sub in $subs){
    Set-AzContext -SubscriptionId $sub.Id | Out-Null
    $wss = Get-AzResource -ResourceType "Microsoft.Databricks/workspaces" -ErrorAction SilentlyContinue
    foreach($w in $wss){
        $rows += [pscustomobject]@{
            SubscriptionName = $sub.Name
            ResourceGroup    = $w.ResourceGroupName
            Workspace        = $w.Name
            Location         = $w.Location
            Sku              = $w.Sku.Name
            Id               = $w.ResourceId
        }
    }
}

$csv = New-StampedPath -BaseDir $OutputDir -Prefix "databricks_workspaces" -Ext 'csv'
Write-CsvSafe -Rows $rows -Path $csv
