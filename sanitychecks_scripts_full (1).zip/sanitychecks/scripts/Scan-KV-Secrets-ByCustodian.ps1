param(
    [Parameter(Mandatory)][string]$TenantId,
    [Parameter(Mandatory)][string]$ClientId,
    [Parameter(Mandatory)][string]$ClientSecret,
    [Parameter(Mandatory)][string]$CsvPath,
    [Parameter(Mandatory)][string]$adh_group,
    [ValidateSet('nonprd','prd')][string]$adh_subscription_type = 'nonprd',
    [Parameter(Mandatory)][string]$OutputDir,
    [string]$BranchName = ''
)
Import-Module (Join-Path $PSScriptRoot 'Common.psm1') -Force
Ensure-Dir -Path $OutputDir
Connect-ScAz -TenantId $TenantId -ClientId $ClientId -ClientSecret $ClientSecret

$subs = Get-ScSubscriptions -AdhGroup $adh_group -Environment $adh_subscription_type
$expected = Import-Csv -Path $CsvPath
$rows = @()

foreach($sub in $subs){
    Set-AzContext -SubscriptionId $sub.Id | Out-Null
    $vaults = Get-AzKeyVault -ErrorAction SilentlyContinue
    foreach($v in $vaults){
        foreach($e in $expected){
            $name = $e.SECRET_NAME
            $exists = 'MISSING'
            try { 
                $s = Get-AzKeyVaultSecret -VaultName $v.VaultName -Name $name -ErrorAction Stop
                if ($s) { $exists = 'EXISTS' }
            } catch {}
            $rows += [pscustomobject]@{
                SubscriptionName = $sub.Name
                Vault            = $v.VaultName
                ResourceGroup    = $v.ResourceGroupName
                SecretName       = $name
                Exists           = $exists
            }
        }
    }
}

$csvOut = New-StampedPath -BaseDir $OutputDir -Prefix "kv_secrets_${adh_group}_${adh_subscription_type}" -Ext 'csv'
Write-CsvSafe -Rows $rows -Path $csvOut
$htmlOut = [System.IO.Path]::ChangeExtension($csvOut, '.html')
Convert-CsvToHtml -CsvPath $csvOut -HtmlPath $htmlOut -Title "KV Secrets ($adh_group / $adh_subscription_type) $BranchName"
