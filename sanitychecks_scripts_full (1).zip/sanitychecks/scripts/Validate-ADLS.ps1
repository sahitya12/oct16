param(
    [Parameter(Mandatory)][string]$TenantId,
    [Parameter(Mandatory)][string]$ClientId,
    [Parameter(Mandatory)][string]$ClientSecret,
    [Parameter(Mandatory)][string]$CsvPath,
    [string]$adh_group = '',
    [ValidateSet('nonprd','prd')][string]$adh_subscription_type = 'nonprd',
    [Parameter(Mandatory)][string]$OutputDir
)
Import-Module (Join-Path $PSScriptRoot 'Common.psm1') -Force
Ensure-Dir -Path $OutputDir
Connect-ScAz -TenantId $TenantId -ClientId $ClientId -ClientSecret $ClientSecret

$subs = if ($adh_group) { Get-ScSubscriptions -AdhGroup $adh_group -Environment $adh_subscription_type } else { Get-ScAllAdhSubscriptions }
$expect = Import-Csv -Path $CsvPath
$rows = @()

foreach($sub in $subs){
    Set-AzContext -SubscriptionId $sub.Id | Out-Null
    foreach($e in $expect){
        $rg  = $e.ResourceGroupName -replace '<Custodian>', $adh_group
        $sa  = $e.StorageAccountName -replace '<Custodian>', $adh_group -replace '<Cust>',$adh_group
        $cnt = $e.ContainerName
        $id  = $e.Identity -replace '<Custodian>', $adh_group

        $saObj = Get-AzStorageAccount -ResourceGroupName $rg -Name $sa -ErrorAction SilentlyContinue
        if (-not $saObj){
            $rows += [pscustomobject]@{ SubscriptionName=$sub.Name; ResourceGroup=$rg; StorageAccount=$sa; Container=$cnt; Path=$e.AccessPath; Identity=$id; Type=$e.Type; Scope=$e.Scope; PermissionType=$e.PermissionType; Actual='N/A'; Status='MISSING'; Details='Storage account not found' }
            continue
        }

        # RBAC check (high level)
        $rbac = Get-AzRoleAssignment -Scope $saObj.Id -ErrorAction SilentlyContinue | Where-Object { $_.DisplayName -eq $id }
        $actual = if ($rbac) { 'RBAC_PRESENT' } else { 'RBAC_NOT_FOUND' }

        # Attempt basic ACL read using Blob DFS (if enabled). This section may require Storage context permissions.
        $status = $actual
        try {
            $ctx = (Get-AzStorageAccount -ResourceGroupName $rg -Name $sa).Context
            $fs = Get-AzDataLakeGen2Item -Context $ctx -FileSystem $cnt -Path $e.AccessPath -ErrorAction SilentlyContinue
            if ($fs) {
                $acl = $fs.Acl
                $status = $status + '; ACL_READ_OK'
            } else {
                $status = $status + '; ACL_PATH_NOT_FOUND'
            }
        } catch {
            $status = $status + '; ACL_READ_FAILED'
        }

        $rows += [pscustomobject]@{
            SubscriptionName = $sub.Name
            ResourceGroup    = $rg
            StorageAccount   = $sa
            Container        = $cnt
            Path             = $e.AccessPath
            Identity         = $id
            Type             = $e.Type
            Scope            = $e.Scope
            PermissionType   = $e.PermissionType
            Actual           = $actual
            Status           = $status
            Details          = ''
        }
    }
}

$csv = New-StampedPath -BaseDir $OutputDir -Prefix "adls_validation" -Ext 'csv'
Write-CsvSafe -Rows $rows -Path $csv
$html = [System.IO.Path]::ChangeExtension($csv, '.html')
Convert-CsvToHtml -CsvPath $csv -HtmlPath $html -Title "ADLS Validation"
