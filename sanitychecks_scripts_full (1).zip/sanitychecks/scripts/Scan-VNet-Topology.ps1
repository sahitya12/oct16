param(
    [Parameter(Mandatory)][string]$TenantId,
    [Parameter(Mandatory)][string]$ClientId,
    [Parameter(Mandatory)][string]$ClientSecret,
    [string]$adh_group = '',
    [ValidateSet('nonprd','prd')][string]$adh_subscription_type = 'nonprd',
    [Parameter(Mandatory)][string]$OutputDir,
    [string]$BranchName = ''
)
Import-Module (Join-Path $PSScriptRoot 'Common.psm1') -Force
Ensure-Dir -Path $OutputDir
Connect-ScAz -TenantId $TenantId -ClientId $ClientId -ClientSecret $ClientSecret

$subs = if ($adh_group) { Get-ScSubscriptions -AdhGroup $adh_group -Environment $adh_subscription_type } else { Get-ScAllAdhSubscriptions }
$rows = @()

foreach($sub in $subs){
    Set-AzContext -SubscriptionId $sub.Id | Out-Null
    $vnets = Get-AzVirtualNetwork -ErrorAction SilentlyContinue
    foreach($v in $vnets){
        $peerings = Get-AzVirtualNetworkPeering -VirtualNetworkName $v.Name -ResourceGroupName $v.ResourceGroupName -ErrorAction SilentlyContinue
        $peerFlat = ($peerings | ForEach-Object { $_.Name + ':' + $_.PeeringState }) -join '; '
        foreach($s in $v.Subnets){
            $rows += [pscustomobject]@{
                SubscriptionName = $sub.Name
                VNet             = $v.Name
                ResourceGroup    = $v.ResourceGroupName
                AddressSpace     = ($v.AddressSpace.AddressPrefixes -join ',')
                Subnet           = $s.Name
                SubnetPrefix     = ($s.AddressPrefix)
                NSG              = ($s.NetworkSecurityGroup.Id)
                RouteTable       = ($s.RouteTable.Id)
                Peerings         = $peerFlat
                Notes            = ''
            }
        }
    }
}

$csv = New-StampedPath -BaseDir $OutputDir -Prefix "vnet_topology" -Ext 'csv'
Write-CsvSafe -Rows $rows -Path $csv
$html = [System.IO.Path]::ChangeExtension($csv, '.html')
Convert-CsvToHtml -CsvPath $csv -HtmlPath $html -Title "VNet & Peering Topology $BranchName"
