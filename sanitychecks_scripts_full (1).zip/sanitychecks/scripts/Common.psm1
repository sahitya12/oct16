# Common.psm1 - shared helpers for sanitychecks scripts
$ErrorActionPreference = 'Stop'

function Connect-ScAz {
    param(
        [Parameter(Mandatory)] [string] $TenantId,
        [Parameter(Mandatory)] [string] $ClientId,
        [Parameter(Mandatory)] [string] $ClientSecret
    )
    Write-Host "Connecting to Azure with Service Principal..." -ForegroundColor Cyan
    try {
        $sec = ConvertTo-SecureString $ClientSecret -AsPlainText -Force
        $cred = New-Object System.Management.Automation.PSCredential($ClientId, $sec)
        Connect-AzAccount -ServicePrincipal -Tenant $TenantId -Credential $cred | Out-Null
    } catch {
        throw "Azure login failed: $($_.Exception.Message)"
    }
}

function Get-ScSubscriptions {
    param(
        [string] $AdhGroup,
        [ValidateSet('nonprd','prd')][string] $Environment = 'nonprd'
    )
    # Pull all subscriptions the SPN can see
    $subs = Get-AzSubscription | Sort-Object Name
    if (-not $subs) { throw "No subscriptions visible to this SPN." }

    # Heuristic filter: ADH + group + env (prd vs nonprd)
    $isProd = $Environment -eq 'prd'
    $envRegex = if ($isProd) { '(prd|prod)' } else { 'nonprd|non[-\s_]?prod|dev|qa|test' }
    $groupRegex = if ([string]::IsNullOrWhiteSpace($AdhGroup)) { '.*' } else { [Regex]::Escape($AdhGroup) }

    $filtered = $subs | Where-Object {
        $_.Name -match 'ADH' -and
        $_.Name -match $groupRegex -and
        $_.Name -match $envRegex
    }

    if (-not $filtered) {
        Write-Warning "No subscriptions matched filters. Returning all ADH subs for investigation."
        $filtered = $subs | Where-Object { $_.Name -match 'ADH' }
    }

    return $filtered
}

function Get-ScAllAdhSubscriptions {
    # Return all ADH subscriptions (both envs)
    $subs = Get-AzSubscription | Where-Object { $_.Name -match 'ADH' } | Sort-Object Name
    if (-not $subs) { throw "No ADH subscriptions visible." }
    return $subs
}

function Ensure-Dir {
    param([Parameter(Mandatory)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) { New-Item -ItemType Directory -Path $Path -Force | Out-Null }
}

function New-StampedPath {
    param([Parameter(Mandatory)][string]$BaseDir,[Parameter(Mandatory)][string]$Prefix,[string]$Ext='csv')
    $ts = (Get-Date).ToString("yyyyMMdd_HHmmss")
    return (Join-Path $BaseDir ("{0}_{1}.{2}" -f $Prefix,$ts,$Ext))
}

function Write-CsvSafe {
    param([Parameter(Mandatory)][object[]]$Rows,[Parameter(Mandatory)][string]$Path)
    $dir = Split-Path -Parent $Path
    Ensure-Dir -Path $dir
    $Rows | Export-Csv -Path $Path -NoTypeInformation -Encoding UTF8
    Write-Host "Wrote CSV: $Path"
}

function Convert-CsvToHtml {
    param([Parameter(Mandatory)][string]$CsvPath,[Parameter(Mandatory)][string]$HtmlPath,[string]$Title="Sanity Check Report")
    $rows = Import-Csv -Path $CsvPath
    $sb = New-Object System.Text.StringBuilder
    [void]$sb.AppendLine('<!DOCTYPE html><html><head><meta charset="utf-8"><title>' + $Title + '</title>')
    [void]$sb.AppendLine('<style>body{font-family:Segoe UI,Roboto,Arial,sans-serif;font-size:13px} table{border-collapse:collapse;width:100%} th,td{border:1px solid #ddd;padding:6px;} th{background:#f4f4f4;text-align:left} .ok{color:green}.warn{color:orange}.err{color:red}</style></head><body>')
    [void]$sb.AppendLine("<h2>$Title</h2>")
    if ($rows.Count -gt 0) {
        $cols = $rows[0].psobject.Properties.Name
        [void]$sb.AppendLine('<table><thead><tr>')
        foreach($c in $cols){ [void]$sb.AppendLine("<th>$c</th>") }
        [void]$sb.AppendLine('</tr></thead><tbody>')
        foreach($r in $rows){
            [void]$sb.AppendLine('<tr>')
            foreach($c in $cols){
                $v = [System.Web.HttpUtility]::HtmlEncode(($r.$c))
                [void]$sb.AppendLine("<td>$v</td>")
            }
            [void]$sb.AppendLine('</tr>')
        }
        [void]$sb.AppendLine('</tbody></table>')
    } else {
        [void]$sb.AppendLine('<p>No rows.</p>')
    }
    [void]$sb.AppendLine('</body></html>')
    $dir = Split-Path -Parent $HtmlPath
    Ensure-Dir -Path $dir
    [System.IO.File]::WriteAllText($HtmlPath, $sb.ToString(), [System.Text.Encoding]::UTF8)
    Write-Host "Wrote HTML: $HtmlPath"
}

Export-ModuleMember -Function *
