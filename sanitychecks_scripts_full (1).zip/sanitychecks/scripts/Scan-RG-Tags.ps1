param(
    [Parameter(Mandatory)][string]$TenantId,
    [Parameter(Mandatory)][string]$ClientId,
    [Parameter(Mandatory)][string]$ClientSecret,
    [string]$adh_group = '',
    [ValidateSet('nonprd','prd')][string]$adh_subscription_type = 'nonprd',
    [Parameter(Mandatory)][string]$OutputDir,
    [string]$BranchName = ''
)
Import-Module (Join-Path $PSScriptRoot 'Common.psm1') -Force
Ensure-Dir -Path $OutputDir
Connect-ScAz -TenantId $TenantId -ClientId $ClientId -ClientSecret $ClientSecret

$subs = if ($adh_group) { Get-ScSubscriptions -AdhGroup $adh_group -Environment $adh_subscription_type } else { Get-ScAllAdhSubscriptions }
$rows = @()
foreach($sub in $subs){
    Set-AzContext -SubscriptionId $sub.Id | Out-Null
    $rgs = Get-AzResourceGroup
    foreach($rg in $rgs){
        $flat = ($rg.Tags.Keys | ForEach-Object { "$_=" + $rg.Tags[$_] }) -join '; '
        $rows += [pscustomobject]@{
            SubscriptionName = $sub.Name
            SubscriptionId   = $sub.Id
            Environment      = $adh_subscription_type
            ResourceGroup    = $rg.ResourceGroupName
            TagsFlat         = $flat
        }
    }
}
$csvOut = New-StampedPath -BaseDir $OutputDir -Prefix "rg_tags" -Ext 'csv'
Write-CsvSafe -Rows $rows -Path $csvOut
$htmlOut = [System.IO.Path]::ChangeExtension($csvOut, '.html')
Convert-CsvToHtml -CsvPath $csvOut -HtmlPath $htmlOut -Title "RG Tags $BranchName"
